const { app, BrowserWindow } = require('electron');

// ESTA ES LA LÍNEA MÁGICA:
app.disableHardwareAcceleration(); 

function createWindow() {
  console.log("Intentando abrir la ventana..."); // Esto saldrá en tu terminal
  const win = new BrowserWindow({
    width: 800,
    height: 600,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false
    }
  });

  win.loadFile('index.html');
}

app.whenReady().then(() => {
    console.log("Electron está listo.");
    createWindow();
});