// ==========================================
// 1. CLASE BASE: FiguraGeometrica
// ==========================================
/**
 * Clase abstracta que define el contrato para cualquier figura.
 * No tiene atributos específicos según la instrucción[cite: 54].
 */
class FiguraGeometrica {
    // Métodos abstractos que deben ser implementados por las subclases [cite: 55, 56]
    calcularArea() {
        throw new Error('Method not implemented');
    }
    
    calcularPerimetro() {
        throw new Error('Method not implemented');
    }
}

// ==========================================
// 2. CLASE DERIVADA: Circulo
// ==========================================
/**
 * Hereda de FiguraGeometrica[cite: 57].
 * Implementa cálculos basados en el 
 *radio[cite: 58].
 */
class Circulo extends FiguraGeometrica {
    constructor(radio) {
        super();
        this.radio = radio;
    }

    calcularArea() {
        return Math.PI * Math.pow(this.radio, 2); // Implementación específica [cite: 61]
    }

    calcularPerimetro() {
        return 2 * Math.PI * this.radio; // Implementación específica [cite: 62]
    }
}

// ==========================================
// 3. CLASE DERIVADA: Triangulo
// ==========================================
/**
 * Hereda de FiguraGeometrica[cite: 63].
 * Utiliza base y altura para el área[cite: 64].
 */
class Triangulo extends FiguraGeometrica {
    constructor(base, altura) {
        super();
        this.base = base;
        this.altura = altura;
    }

    calcularArea() {
        return (this.base * this.altura) / 2; // Implementación específica [cite: 66]
    }

    calcularPerimetro() {
        // Asumiendo un triángulo equilátero para cumplir con la funcionalidad [cite: 72]
        return 3 * this.base;
    }
}

// ==========================================
// 4. CLASE DERIVADA: Rectangulo
// ==========================================
/**
 * Hereda de FiguraGeometrica[cite: 73].
 * Utiliza largo y ancho para sus cálculos[cite: 74].
 */
class Rectangulo extends FiguraGeometrica {
    constructor(largo, ancho) {
        super();
        this.largo = largo;
        this.ancho = ancho;
    }

    calcularArea() {
        return this.largo * this.ancho; // Implementación específica [cite: 76]
    }

    calcularPerimetro() {
        return 2 * (this.largo + this.ancho); // Implementación específica [cite: 76]
    }
}

