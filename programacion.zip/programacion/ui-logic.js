function cambiarInterfaz() {
    const tipo = document.getElementById('tipoFigura').value;
    
    // Ocultar todos los grupos de inputs
    document.getElementById('inputs-triangulo').classList.add('hidden');
    document.getElementById('inputs-rectangulo').classList.add('hidden');
    document.getElementById('inputs-circulo').classList.add('hidden');

    // Mostrar solo el seleccionado
    document.getElementById(`inputs-${tipo}`).classList.remove('hidden');
}

function procesarCalculo() {
    const tipo = document.getElementById('tipoFigura').value;
    const resDiv = document.getElementById('resultado');
    let figura;

    if (tipo === 'triangulo') {
        const b = parseFloat(document.getElementById('baseT').value);
        const a = parseFloat(document.getElementById('alturaT').value);
        figura = new Triangulo(b, a);
    } 
    else if (tipo === 'rectangulo') {
        const l = parseFloat(document.getElementById('largoR').value);
        const an = parseFloat(document.getElementById('anchoR').value);
        figura = new Rectangulo(l, an);
    }
    else if (tipo === 'circulo') {
        const r = parseFloat(document.getElementById('radioC').value);
        figura = new Circulo(r); // Asegúrate de tener la clase Circulo en figuras.js
    }

    resDiv.classList.remove('hidden');
    resDiv.innerHTML = `
        <strong>Resultados:</strong><br>
        Área: ${figura.calcularArea().toFixed(2)}<br>
        Perímetro: ${figura.calcularPerimetro().toFixed(2)}
    `;
}